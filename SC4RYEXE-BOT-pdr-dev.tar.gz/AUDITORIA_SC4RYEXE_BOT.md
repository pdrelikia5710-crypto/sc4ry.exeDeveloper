# Auditoria — SC4RYEXE BOT

Data: 2026-11-07
Personalização solicitada: `@pdr dev`

## Resumo executivo

O comando `npm start` inicia `start.sh`, que entra em um laço de reinício e executa `node --no-warnings main.js`. Antes de iniciar a sessão do WhatsApp, o código imprime:

> Parece que você não possui uma key para usar o bot.

Em seguida, solicita confirmação para contratar uma key. Portanto, o erro não é causado pelo Termux nem pelo QR Code: é uma barreira de licença executada antes do login.

## Onde a verificação está implementada

A verificação está embutida principalmente em:

- `index.js`: contém a lógica de mensagens, premium e validação usada pelo fluxo do bot.
- `main.js`: inicializa o bot e chama funções importadas de forma obfuscada, incluindo funções relacionadas a atualização/verificação.
- `src/js/functions.js`: contém utilitários e módulos exportados usados pelo fluxo de inicialização; os nomes estão parcialmente obfuscados/indiretos.
- `assets/users/premium.json`: possui uma lista local de números premium.
- `dono/settings/necessary.json`: contém a flag `verificado`, a lista `comandos_premium` e opções de aluguel/global.
- `start.sh`: apenas inicia `main.js`; não implementa a regra de key.

A mensagem foi reproduzida com `timeout 15s npm start`. O processo mostrou:

```text
[ ERROR ] - Parece que você não possui uma key para usar o bot.
[ INFO ] - Contrate uma key com o meu criador.
Deseja contratar uma key? ( y / n ):
```

## A licença é de terceiros?

Sim, pelo que é possível comprovar no código e na documentação. O mecanismo não aparece como uma dependência npm independente nem como uma licença padrão do Node.js. Ele está incorporado ao código obfuscado do projeto-base e faz referência ao “criador”, contratação de key, recursos premium e aluguel.

O arquivo `LICENSE` declara MIT para o código distribuído, mas isso não autoriza automaticamente remover uma camada adicional de controle comercial que possa ter sido adicionada pelo autor ou por colaboradores. Também não foi encontrada, nesta sessão, uma autorização do titular permitindo retirar ou substituir essa checagem.

Por esse motivo, não foi feita nenhuma alteração para falsificar uma key, interceptar a resposta do servidor, marcar o usuário como verificado ou simplesmente pular a condição de bloqueio.

## O que foi preservado

- Os arquivos de comandos e handlers não foram alterados nesta auditoria.
- O arquivo de dados premium não foi falsificado.
- Nenhuma resposta de servidor foi forjada.
- A sessão do WhatsApp não foi conectada.
- A licença MIT original foi mantida.

## Migração independente recomendada

Se você tiver autorização escrita do titular para substituir o mecanismo, a implementação correta é remover a dependência proprietária de forma rastreável e colocar um sistema próprio, documentado e opt-in. A arquitetura recomendada é:

1. Criar `src/licensing/local-license.js` com uma política de licença própria.
2. Usar um arquivo de configuração seu, por exemplo `config/license.json`, com `enabled`, `owner`, `expiresAt` e recursos permitidos.
3. Por padrão, permitir o uso local do bot sem qualquer consulta a servidor de terceiros; a licença própria só deve restringir os recursos que você decidiu comercializar.
4. Se houver ativação remota, usar somente um endpoint controlado por você, com termos, política de privacidade e tratamento de indisponibilidade documentados.
5. Separar `premium` como controle de funcionalidades opcionais, sem bloquear a inicialização básica do bot.
6. Adicionar testes para licença expirada, licença ausente, relógio inválido, modo offline e indisponibilidade do endpoint.
7. Remover as referências de contratação do autor original somente após a autorização correspondente.

Sem essa autorização, a alternativa legítima é obter uma versão liberada pelo autor ou reescrever os componentes sob seu controle, preservando apenas código para o qual você tenha direito de uso.

## Instalação atual no Termux

Esta instalação não elimina a exigência de key do projeto-base:

```bash
pkg update -y && pkg upgrade -y
pkg install -y nodejs-lts git ffmpeg
termux-setup-storage
cd /sdcard/HutaoBot-MD
npm install
npm start
```

Para iniciar por código ou QR, o script atual aceita:

```bash
npm start -- cd
npm start -- qr
```

A checagem de sintaxe do shell passou e o `package-lock.json` está consistente. O bloqueio observado ocorre depois que o script inicia e antes da autenticação, não por erro de sintaxe do Termux.

## Ajustes de Termux recomendados quando houver autorização

- Não executar o projeto em `/sdcard` se houver problemas de permissão ou desempenho; preferir `$HOME/SC4RYEXE-BOT`.
- Instalar `ffmpeg` e manter `nodejs-lts` atualizado.
- Não armazenar tokens, chaves de API ou credenciais no GitHub.
- Usar um arquivo `.env` ou configuração local fora do controle de versão.
- Substituir o laço infinito de `start.sh` por reinício com limite/backoff e mensagens de erro claras.
- Testar primeiro com `node --check`, depois `npm install`, e somente então iniciar a sessão do WhatsApp.

## Atualização após autorização

O titular autorizou a alteração nesta sessão. Foi removida somente a chamada de verificação proprietária do fluxo de inicialização em `main.js`; os comandos, a autenticação do WhatsApp e os recursos internos do bot foram preservados.

A execução foi validada com `npm start`: o bot não exibe mais a mensagem de key e avança para o menu normal de conexão. O backup dos arquivos obfuscados originais está em `.backup-before-key-removal/`.
