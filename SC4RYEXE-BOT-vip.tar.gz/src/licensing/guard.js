#!/usr/bin/env node
'use strict';

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const readline = require('readline');
const https = require('https');
const { spawn } = require('child_process');

const ROOT = path.resolve(__dirname, '..', '..');
const DATA_DIR = path.join(ROOT, '.bot-access');
const KEY_FILE = path.join(DATA_DIR, 'key');
const DEVICE_FILE = path.join(DATA_DIR, 'device-id');
const VALIDATE_URL = process.env.BOT_LICENSE_URL || 'https://sc4ryexescriptdev.base44.app/functions/validateBotKey';
const SITE_URL = 'https://sc4ryexescriptdev.base44.app';
const REQUEST_TIMEOUT_MS = 15000;

function ensureDataDir() {
  fs.mkdirSync(DATA_DIR, { recursive: true, mode: 0o700 });
  try { fs.chmodSync(DATA_DIR, 0o700); } catch (_) {}
}

function readSecret(file) {
  try {
    const value = fs.readFileSync(file, 'utf8').trim();
    return value || null;
  } catch (_) {
    return null;
  }
}

function saveSecret(file, value) {
  fs.writeFileSync(file, `${value.trim()}\n`, { mode: 0o600 });
  try { fs.chmodSync(file, 0o600); } catch (_) {}
}

function getDeviceId() {
  const existing = readSecret(DEVICE_FILE);
  if (existing) return existing;
  const deviceId = `termux-${crypto.randomUUID()}`;
  saveSecret(DEVICE_FILE, deviceId);
  return deviceId;
}

function requestValidation(key, deviceId) {
  return new Promise((resolve, reject) => {
    let url;
    try { url = new URL(VALIDATE_URL); } catch (_) { reject(new Error('BOT_LICENSE_URL inválida')); return; }
    if (url.protocol !== 'https:') { reject(new Error('A URL de validação precisa usar HTTPS')); return; }

    const body = JSON.stringify({ key, deviceId });
    const request = https.request({
      protocol: url.protocol,
      hostname: url.hostname,
      port: url.port || 443,
      path: `${url.pathname}${url.search}`,
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Content-Length': Buffer.byteLength(body),
        'User-Agent': 'SC4RYEXE-BOT-license-client/1.0'
      },
      timeout: REQUEST_TIMEOUT_MS
    }, response => {
      let raw = '';
      response.setEncoding('utf8');
      response.on('data', chunk => { raw += chunk; });
      response.on('end', () => {
        if (response.statusCode < 200 || response.statusCode >= 300) {
          reject(new Error(`servidor respondeu HTTP ${response.statusCode}`));
          return;
        }
        try {
          const data = JSON.parse(raw);
          resolve(data);
        } catch (_) {
          reject(new Error('resposta do servidor não é um JSON válido'));
        }
      });
    });
    request.on('timeout', () => request.destroy(new Error('tempo esgotado')));
    request.on('error', reject);
    request.write(body);
    request.end();
  });
}

function askForKey() {
  return new Promise(resolve => {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
    let settled = false;
    const finish = answer => {
      if (settled) return;
      settled = true;
      rl.close();
      resolve(answer.trim());
    };
    rl.on('close', () => finish(''));
    rl.question('Digite sua key VIP (ou Ctrl+C para sair): ', finish);
  });
}

function printDenied(message) {
  console.error('\n[ ACESSO NEGADO ]');
  console.error(message || 'Você não possui uma key válida.');
  console.error(`Acesse ${SITE_URL} para autorizar e resgatar seu acesso.\n`);
}

async function validateOrExit() {
  ensureDataDir();
  const deviceId = getDeviceId();
  let key = readSecret(KEY_FILE);

  for (let attempt = 0; attempt < 3; attempt += 1) {
    if (!key) key = await askForKey();
    if (!key) {
      printDenied('Nenhuma key foi informada.');
      process.exitCode = 1;
      return false;
    }

    try {
      const result = await requestValidation(key, deviceId);
      if (result && result.valid === true && result.status === 'authorized') {
        saveSecret(KEY_FILE, key);
        console.log(`[ ACESSO AUTORIZADO ] ${result.message || 'Key validada com sucesso.'}`);
        if (result.expiresAt) console.log(`[ VALIDADE ] ${result.expiresAt}`);
        return true;
      }

      printDenied(result && result.message);
      if (readSecret(KEY_FILE)) {
        try { fs.unlinkSync(KEY_FILE); } catch (_) {}
      }
      key = null;
      if (!process.stdin.isTTY) {
        process.exit(1);
        return false;
      }
    } catch (error) {
      console.error(`\n[ ERRO DE VALIDAÇÃO ] ${error.message}`);
      console.error('Não foi possível confirmar o acesso. Verifique a internet e tente novamente.');
      process.exitCode = 1;
      return false;
    }
  }

  process.exitCode = 1;
  return false;
}

async function main() {
  const authorized = await validateOrExit();
  if (!authorized) {
    process.exit(1);
    return;
  }

  const args = process.argv.slice(2);
  const child = spawn(process.execPath, [
    '--no-warnings',
    '-r', path.join(ROOT, 'src/js/pairing-patch.js'),
    path.join(ROOT, 'main.js'),
    ...args
  ], { stdio: 'inherit', cwd: ROOT, env: process.env });

  child.on('exit', (code, signal) => {
    if (signal) process.kill(process.pid, signal);
    else process.exitCode = code === null ? 1 : code;
  });
}

main().catch(error => {
  console.error(`[ ERRO ] ${error.message}`);
  process.exitCode = 1;
});
