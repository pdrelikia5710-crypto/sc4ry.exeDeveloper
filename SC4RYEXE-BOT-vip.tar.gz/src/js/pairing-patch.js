'use strict';

/*
 * Compatibilidade para Baileys 6.7.x:
 * requestPairingCode() pode ser chamado antes de o WebSocket terminar o
 * handshake. Nesse caso a biblioteca retorna Boom 428 / Connection Closed.
 * Este patch aguarda connection=open somente no fluxo de pareamento por
 * número; QR Code e os demais recursos permanecem inalterados.
 */

const Module = require('module');
const originalLoad = Module._load;
const patched = Symbol.for('sc4ryexe.pairingPatch');

function statusCodeOf(error) {
  return error?.output?.statusCode ?? error?.data?.statusCode ?? error?.statusCode;
}

function waitForConnectionOpen(sock, timeoutMs = 30000) {
  if (!sock?.ev?.on) return Promise.resolve();
  if (sock.ws?.isOpen) return Promise.resolve();
  if (sock.ws?.isClosed || sock.ws?.isClosing) {
    return Promise.reject(new Error(
      'O WebSocket do WhatsApp já foi fechado. Apague a sessão incompleta e tente novamente.'
    ));
  }
  if (typeof sock.waitForSocketOpen === 'function') {
    return sock.waitForSocketOpen();
  }

  return new Promise((resolve, reject) => {
    let timer;
    const finish = (fn, value) => {
      clearTimeout(timer);
      sock.ev.off?.('connection.update', onUpdate);
      fn(value);
    };
    const onUpdate = ({ connection, lastDisconnect }) => {
      if (connection === 'open') return finish(resolve);
      if (connection === 'close') {
        const code = statusCodeOf(lastDisconnect?.error);
        return finish(reject, new Error(
          code === 428
            ? 'O WhatsApp fechou a conexão antes do pareamento. Tente novamente após apagar a sessão incompleta.'
            : 'A conexão com o WhatsApp foi encerrada antes do pareamento.'
        ));
      }
    };
    timer = setTimeout(() => finish(reject, new Error(
      'Tempo esgotado aguardando a conexão do WhatsApp para gerar o código.'
    )), timeoutMs);
    sock.ev.on('connection.update', onUpdate);
  });
}

function wrapSocket(sock) {
  if (!sock || typeof sock.requestPairingCode !== 'function' || sock[patched]) return sock;
  const requestPairingCode = sock.requestPairingCode.bind(sock);
  sock.requestPairingCode = async (...args) => {
    await waitForConnectionOpen(sock);
    try {
      return await requestPairingCode(...args);
    } catch (error) {
      if (statusCodeOf(error) === 428) {
        throw new Error(
          'O WhatsApp fechou a conexão durante o pareamento. Apague a pasta de sessão incompleta, reinicie o bot e tente novamente.'
        );
      }
      throw error;
    }
  };
  Object.defineProperty(sock, patched, { value: true, enumerable: false });
  return sock;
}

function wrapFactory(factory) {
  if (typeof factory !== 'function' || factory[patched]) return factory;
  const wrapped = function (...args) {
    return wrapSocket(factory.apply(this, args));
  };
  Object.setPrototypeOf(wrapped, Object.getPrototypeOf(factory));
  wrapped[patched] = true;
  return wrapped;
}

Module._load = function (request, parent, isMain) {
  const loaded = originalLoad.call(this, request, parent, isMain);
  if (request === '@whiskeysockets/baileys' && loaded && !loaded[patched]) {
    if (typeof loaded.default === 'function') loaded.default = wrapFactory(loaded.default);
    if (typeof loaded.makeWASocket === 'function') loaded.makeWASocket = wrapFactory(loaded.makeWASocket);
    Object.defineProperty(loaded, patched, { value: true, enumerable: false });
  }
  return loaded;
};
