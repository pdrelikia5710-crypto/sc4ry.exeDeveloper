#!/bin/bash

updateBot() {
  NODE_ENV=production node --no-warnings src/licensing/guard.js up
}

startWithCode() {
  NODE_ENV=production node --no-warnings src/licensing/guard.js cd
}


startWithQr() {
  NODE_ENV=production node --no-warnings src/licensing/guard.js qr
}

defaultStart() {
  NODE_ENV=production node --no-warnings src/licensing/guard.js
}

while :
do
  echo -e "    \033[1;33mHUTAO BOT V9.0 VIP 💎 ^-^\n INICIANDO, AGUARDE UM MOMENTO...🍾\033[0m"
  if [ "$1" = "up" ]; then
    updateBot
  elif [ "$1" = "cd" ]; then
    startWithCode
  elif [ "$1" = "qr" ]; then
    startWithQr
  else 
    defaultStart
  fi
  sleep 1
done
